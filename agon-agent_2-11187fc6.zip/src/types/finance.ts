export interface UserProfile {
  name: string;
  age: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  existingInvestments: number;
  existingDebts: number;
  emergencyFund: number;
  hasHealthInsurance: boolean;
  hasLifeInsurance: boolean;
  hasTermInsurance: boolean;
  investmentTypes: string[];
  taxRegime: 'old' | 'new';
  riskTolerance: 'conservative' | 'moderate' | 'aggressive';
  retirementAge: number;
  dependents: number;
}

export interface HealthScore {
  overall: number;
  emergencyPreparedness: number;
  insuranceCoverage: number;
  investmentDiversification: number;
  debtHealth: number;
  taxEfficiency: number;
  retirementReadiness: number;
}

export interface ScoreBreakdown {
  dimension: string;
  score: number;
  maxScore: number;
  status: 'excellent' | 'good' | 'needs-attention' | 'critical';
  recommendation: string;
}

export interface AIInsight {
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  actionItems: string[];
}
