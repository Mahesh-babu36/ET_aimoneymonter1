import { useState } from 'react';
import type { UserProfile } from './types/finance';
import LandingPage from './components/LandingPage';
import OnboardingFlow from './components/OnboardingFlow';
import Dashboard from './components/Dashboard';

type AppState = 'landing' | 'onboarding' | 'dashboard';

export default function App() {
  const [appState, setAppState] = useState<AppState>('landing');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const handleStart = () => {
    setAppState('onboarding');
  };

  const handleOnboardingComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    setAppState('dashboard');
  };

  const handleReset = () => {
    setUserProfile(null);
    setAppState('landing');
  };

  return (
    <>
      {appState === 'landing' && <LandingPage onStart={handleStart} />}
      {appState === 'onboarding' && <OnboardingFlow onComplete={handleOnboardingComplete} />}
      {appState === 'dashboard' && userProfile && (
        <Dashboard profile={userProfile} onReset={handleReset} />
      )}
    </>
  );
}
