import type { UserProfile, HealthScore, AIInsight } from '../types/finance';

const GEMINI_API_KEY = 'AIzaSyBOgxhN5bPrR8fA2fdoViK4REN6BP6jzjc';

export async function getAIAnalysis(profile: UserProfile, scores: HealthScore): Promise<AIInsight[]> {
  const prompt = `You are an expert Indian financial advisor. Analyze this financial profile and provide actionable insights.

User Profile:
- Age: ${profile.age}
- Monthly Income: ₹${profile.monthlyIncome.toLocaleString('en-IN')}
- Monthly Expenses: ₹${profile.monthlyExpenses.toLocaleString('en-IN')}
- Existing Investments: ₹${profile.existingInvestments.toLocaleString('en-IN')}
- Existing Debts: ₹${profile.existingDebts.toLocaleString('en-IN')}
- Emergency Fund: ₹${profile.emergencyFund.toLocaleString('en-IN')}
- Has Health Insurance: ${profile.hasHealthInsurance ? 'Yes' : 'No'}
- Has Life Insurance: ${profile.hasLifeInsurance ? 'Yes' : 'No'}
- Has Term Insurance: ${profile.hasTermInsurance ? 'Yes' : 'No'}
- Investment Types: ${profile.investmentTypes.join(', ') || 'None'}
- Tax Regime: ${profile.taxRegime}
- Risk Tolerance: ${profile.riskTolerance}
- Target Retirement Age: ${profile.retirementAge}
- Dependents: ${profile.dependents}

Health Scores (out of 100):
- Overall: ${scores.overall}
- Emergency Preparedness: ${scores.emergencyPreparedness}
- Insurance Coverage: ${scores.insuranceCoverage}
- Investment Diversification: ${scores.investmentDiversification}
- Debt Health: ${scores.debtHealth}
- Tax Efficiency: ${scores.taxEfficiency}
- Retirement Readiness: ${scores.retirementReadiness}

Provide exactly 4 personalized financial insights in this exact JSON format (no markdown, just raw JSON):
[
  {
    "title": "Short title",
    "description": "Detailed explanation in 2-3 sentences",
    "priority": "high|medium|low",
    "actionItems": ["Action 1", "Action 2", "Action 3"]
  }
]

Focus on Indian context: PPF, NPS, ELSS, Section 80C, 80D, HRA, mutual funds, SIPs, term insurance, health insurance. Be specific with numbers and recommendations.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048,
          },
        }),
      }
    );

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    
    // Extract JSON from response
    const jsonMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    
    return getDefaultInsights(profile, scores);
  } catch (error) {
    console.error('Gemini API error:', error);
    return getDefaultInsights(profile, scores);
  }
}

export async function getDetailedRecommendations(profile: UserProfile, dimension: string): Promise<string> {
  const prompt = `You are an expert Indian financial advisor. The user needs detailed advice on: ${dimension}

User Profile:
- Age: ${profile.age}
- Monthly Income: ₹${profile.monthlyIncome.toLocaleString('en-IN')}
- Monthly Expenses: ₹${profile.monthlyExpenses.toLocaleString('en-IN')}
- Savings Rate: ${(((profile.monthlyIncome - profile.monthlyExpenses) / profile.monthlyIncome) * 100).toFixed(1)}%
- Existing Investments: ₹${profile.existingInvestments.toLocaleString('en-IN')}
- Emergency Fund: ₹${profile.emergencyFund.toLocaleString('en-IN')}
- Risk Tolerance: ${profile.riskTolerance}
- Dependents: ${profile.dependents}

Provide a detailed, actionable 200-word recommendation specific to ${dimension}. Include:
1. Current situation assessment
2. Specific steps to improve
3. Recommended products/instruments (Indian context)
4. Timeline and targets

Be specific with numbers. Use Indian financial products: PPF, NPS, ELSS, FDs, mutual funds, etc.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 1024,
          },
        }),
      }
    );

    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || 'Unable to generate recommendations. Please try again.';
  } catch (error) {
    console.error('Gemini API error:', error);
    return 'Unable to generate recommendations. Please check your connection and try again.';
  }
}

function getDefaultInsights(profile: UserProfile, scores: HealthScore): AIInsight[] {
  const insights: AIInsight[] = [];
  
  if (scores.emergencyPreparedness < 60) {
    insights.push({
      title: 'Build Your Emergency Fund',
      description: `Your emergency fund of ₹${profile.emergencyFund.toLocaleString('en-IN')} covers less than 6 months of expenses. This leaves you vulnerable to unexpected events.`,
      priority: 'high',
      actionItems: [
        `Target ₹${(profile.monthlyExpenses * 6).toLocaleString('en-IN')} in emergency fund`,
        'Keep funds in liquid mutual funds or high-yield savings',
        'Automate monthly transfers to emergency fund'
      ]
    });
  }
  
  if (scores.insuranceCoverage < 60) {
    insights.push({
      title: 'Critical Insurance Gaps',
      description: 'You lack essential insurance coverage that protects your family from financial hardship.',
      priority: 'high',
      actionItems: [
        'Get term insurance of 10-15x annual income',
        'Ensure health insurance of at least ₹10 lakhs',
        'Consider super top-up health plans'
      ]
    });
  }
  
  if (scores.investmentDiversification < 60) {
    insights.push({
      title: 'Diversify Your Investments',
      description: 'Your investment portfolio lacks diversification, increasing your risk exposure.',
      priority: 'medium',
      actionItems: [
        'Start SIPs in equity mutual funds',
        'Consider index funds for low-cost diversification',
        'Add debt funds for stability'
      ]
    });
  }
  
  if (scores.retirementReadiness < 60) {
    insights.push({
      title: 'Accelerate Retirement Planning',
      description: `At your current pace, you may not have enough for a comfortable retirement by age ${profile.retirementAge}.`,
      priority: 'high',
      actionItems: [
        'Maximize NPS contributions for tax benefits',
        'Increase equity allocation while young',
        'Use PPF for guaranteed returns'
      ]
    });
  }
  
  return insights.slice(0, 4);
}
