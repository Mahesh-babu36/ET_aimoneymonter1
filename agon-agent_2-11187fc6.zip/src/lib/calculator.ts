import type { UserProfile, HealthScore, ScoreBreakdown } from '../types/finance';

export function calculateHealthScore(profile: UserProfile): HealthScore {
  const emergencyPreparedness = calculateEmergencyScore(profile);
  const insuranceCoverage = calculateInsuranceScore(profile);
  const investmentDiversification = calculateInvestmentScore(profile);
  const debtHealth = calculateDebtScore(profile);
  const taxEfficiency = calculateTaxScore(profile);
  const retirementReadiness = calculateRetirementScore(profile);
  
  const overall = Math.round(
    (emergencyPreparedness * 0.15 +
    insuranceCoverage * 0.20 +
    investmentDiversification * 0.20 +
    debtHealth * 0.15 +
    taxEfficiency * 0.10 +
    retirementReadiness * 0.20)
  );
  
  return {
    overall,
    emergencyPreparedness,
    insuranceCoverage,
    investmentDiversification,
    debtHealth,
    taxEfficiency,
    retirementReadiness,
  };
}

function calculateEmergencyScore(profile: UserProfile): number {
  const monthsCovered = profile.emergencyFund / profile.monthlyExpenses;
  if (monthsCovered >= 12) return 100;
  if (monthsCovered >= 6) return 80;
  if (monthsCovered >= 3) return 50;
  if (monthsCovered >= 1) return 30;
  return 10;
}

function calculateInsuranceScore(profile: UserProfile): number {
  let score = 0;
  if (profile.hasHealthInsurance) score += 40;
  if (profile.hasTermInsurance) score += 40;
  if (profile.hasLifeInsurance) score += 20;
  
  // Bonus for having dependents and insurance
  if (profile.dependents > 0 && profile.hasTermInsurance && profile.hasHealthInsurance) {
    score = Math.min(100, score + 10);
  }
  
  return score;
}

function calculateInvestmentScore(profile: UserProfile): number {
  const types = profile.investmentTypes;
  let score = 0;
  
  // Diversity scoring
  const hasEquity = types.some(t => ['stocks', 'equity-mf', 'elss'].includes(t));
  const hasDebt = types.some(t => ['fd', 'ppf', 'debt-mf', 'bonds'].includes(t));
  const hasAlternative = types.some(t => ['gold', 'real-estate', 'nps'].includes(t));
  
  if (hasEquity) score += 35;
  if (hasDebt) score += 35;
  if (hasAlternative) score += 20;
  
  // Investment to income ratio
  const investmentRatio = profile.existingInvestments / (profile.monthlyIncome * 12);
  if (investmentRatio >= 2) score += 10;
  else if (investmentRatio >= 1) score += 5;
  
  return Math.min(100, score);
}

function calculateDebtScore(profile: UserProfile): number {
  if (profile.existingDebts === 0) return 100;
  
  const debtToIncomeRatio = profile.existingDebts / (profile.monthlyIncome * 12);
  
  if (debtToIncomeRatio <= 0.1) return 90;
  if (debtToIncomeRatio <= 0.3) return 70;
  if (debtToIncomeRatio <= 0.5) return 50;
  if (debtToIncomeRatio <= 1) return 30;
  return 10;
}

function calculateTaxScore(profile: UserProfile): number {
  let score = 50; // Base score
  
  const types = profile.investmentTypes;
  
  // Tax-saving investments
  if (types.includes('elss')) score += 15;
  if (types.includes('ppf')) score += 15;
  if (types.includes('nps')) score += 15;
  if (profile.hasHealthInsurance) score += 5; // 80D benefit
  
  return Math.min(100, score);
}

function calculateRetirementScore(profile: UserProfile): number {
  const yearsToRetirement = profile.retirementAge - profile.age;
  const monthlySavings = profile.monthlyIncome - profile.monthlyExpenses;
  const annualSavings = monthlySavings * 12;
  
  // Simple retirement corpus calculation
  // Assuming 12% returns, 6% inflation
  const realReturn = 0.06;
  const targetCorpus = profile.monthlyExpenses * 12 * 25; // 25x annual expenses
  
  // Future value of current investments + future savings
  const fvInvestments = profile.existingInvestments * Math.pow(1 + realReturn, yearsToRetirement);
  const fvSavings = annualSavings * ((Math.pow(1 + realReturn, yearsToRetirement) - 1) / realReturn);
  const projectedCorpus = fvInvestments + fvSavings;
  
  const readinessRatio = projectedCorpus / targetCorpus;
  
  if (readinessRatio >= 1.2) return 100;
  if (readinessRatio >= 1) return 85;
  if (readinessRatio >= 0.75) return 70;
  if (readinessRatio >= 0.5) return 50;
  if (readinessRatio >= 0.25) return 30;
  return 15;
}

export function getScoreBreakdown(profile: UserProfile, scores: HealthScore): ScoreBreakdown[] {
  const getStatus = (score: number): 'excellent' | 'good' | 'needs-attention' | 'critical' => {
    if (score >= 80) return 'excellent';
    if (score >= 60) return 'good';
    if (score >= 40) return 'needs-attention';
    return 'critical';
  };
  
  return [
    {
      dimension: 'Emergency Preparedness',
      score: scores.emergencyPreparedness,
      maxScore: 100,
      status: getStatus(scores.emergencyPreparedness),
      recommendation: scores.emergencyPreparedness < 60 
        ? `Build emergency fund to ₹${(profile.monthlyExpenses * 6).toLocaleString('en-IN')}`
        : 'Your emergency fund is healthy'
    },
    {
      dimension: 'Insurance Coverage',
      score: scores.insuranceCoverage,
      maxScore: 100,
      status: getStatus(scores.insuranceCoverage),
      recommendation: scores.insuranceCoverage < 60
        ? 'Get term insurance and health insurance immediately'
        : 'Your insurance coverage is adequate'
    },
    {
      dimension: 'Investment Diversification',
      score: scores.investmentDiversification,
      maxScore: 100,
      status: getStatus(scores.investmentDiversification),
      recommendation: scores.investmentDiversification < 60
        ? 'Diversify across equity, debt, and alternative assets'
        : 'Good investment diversification'
    },
    {
      dimension: 'Debt Health',
      score: scores.debtHealth,
      maxScore: 100,
      status: getStatus(scores.debtHealth),
      recommendation: scores.debtHealth < 60
        ? 'Focus on paying off high-interest debt first'
        : 'Your debt levels are manageable'
    },
    {
      dimension: 'Tax Efficiency',
      score: scores.taxEfficiency,
      maxScore: 100,
      status: getStatus(scores.taxEfficiency),
      recommendation: scores.taxEfficiency < 60
        ? 'Maximize 80C, 80D deductions with ELSS, PPF, NPS'
        : 'You are utilizing tax-saving options well'
    },
    {
      dimension: 'Retirement Readiness',
      score: scores.retirementReadiness,
      maxScore: 100,
      status: getStatus(scores.retirementReadiness),
      recommendation: scores.retirementReadiness < 60
        ? 'Increase retirement contributions significantly'
        : 'On track for retirement goals'
    },
  ];
}

export function formatCurrency(amount: number): string {
  if (amount >= 10000000) {
    return `₹${(amount / 10000000).toFixed(2)} Cr`;
  } else if (amount >= 100000) {
    return `₹${(amount / 100000).toFixed(2)} L`;
  } else {
    return `₹${amount.toLocaleString('en-IN')}`;
  }
}
