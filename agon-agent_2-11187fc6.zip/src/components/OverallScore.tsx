import { motion } from 'framer-motion';
import { Award, TrendingUp, AlertTriangle, XCircle } from 'lucide-react';

interface OverallScoreProps {
  score: number;
  name: string;
}

export default function OverallScore({ score, name }: OverallScoreProps) {
  const getScoreGrade = () => {
    if (score >= 80) return { grade: 'Excellent', color: 'text-emerald-400', bg: 'from-emerald-500/20 to-teal-500/20', icon: Award };
    if (score >= 60) return { grade: 'Good', color: 'text-blue-400', bg: 'from-blue-500/20 to-cyan-500/20', icon: TrendingUp };
    if (score >= 40) return { grade: 'Needs Work', color: 'text-amber-400', bg: 'from-amber-500/20 to-orange-500/20', icon: AlertTriangle };
    return { grade: 'Critical', color: 'text-red-400', bg: 'from-red-500/20 to-rose-500/20', icon: XCircle };
  };

  const { grade, color, bg, icon: Icon } = getScoreGrade();

  const circumference = 2 * Math.PI * 90;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`bg-gradient-to-br ${bg} backdrop-blur-xl border border-slate-700/50 rounded-3xl p-8 text-center`}
    >
      <h2 className="text-slate-400 text-sm font-medium mb-2">Welcome back, {name || 'Investor'}!</h2>
      <h1 className="text-2xl font-bold text-white mb-8">Your Money Health Score</h1>

      <div className="relative w-56 h-56 mx-auto mb-8">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="112"
            cy="112"
            r="90"
            stroke="currentColor"
            strokeWidth="12"
            fill="none"
            className="text-slate-700/50"
          />
          <motion.circle
            cx="112"
            cy="112"
            r="90"
            stroke="url(#scoreGradient)"
            strokeWidth="12"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.5, ease: 'easeOut' }}
          />
          <defs>
            <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#14b8a6" />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span
            className="text-6xl font-bold text-white"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {score}
          </motion.span>
          <span className="text-slate-400 text-sm">out of 100</span>
        </div>
      </div>

      <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${color} bg-slate-800/50`}>
        <Icon className="w-5 h-5" />
        <span className="font-semibold">{grade}</span>
      </div>

      <p className="text-slate-400 text-sm mt-4 max-w-sm mx-auto">
        {score >= 80
          ? "You're on track for financial success! Keep up the great work."
          : score >= 60
          ? "You're doing well, but there's room for improvement in some areas."
          : score >= 40
          ? "Your finances need attention. Focus on the critical areas below."
          : "Your financial health is at risk. Take immediate action on the recommendations."}
      </p>
    </motion.div>
  );
}
