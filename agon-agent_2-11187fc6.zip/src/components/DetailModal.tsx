import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles, Loader2 } from 'lucide-react';
import type { UserProfile, ScoreBreakdown } from '../types/finance';
import { getDetailedRecommendations } from '../lib/gemini';

interface DetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  breakdown: ScoreBreakdown | null;
  profile: UserProfile;
}

export default function DetailModal({ isOpen, onClose, breakdown, profile }: DetailModalProps) {
  const [recommendations, setRecommendations] = useState<string>('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && breakdown) {
      setLoading(true);
      setRecommendations('');
      getDetailedRecommendations(profile, breakdown.dimension)
        .then(setRecommendations)
        .finally(() => setLoading(false));
    }
  }, [isOpen, breakdown, profile]);

  if (!breakdown) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-x-4 top-[10%] md:inset-x-auto md:left-1/2 md:-translate-x-1/2 md:w-full md:max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl z-50 max-h-[80vh] overflow-hidden"
          >
            <div className="p-6 border-b border-slate-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">{breakdown.dimension}</h2>
                    <p className="text-slate-400 text-sm">AI-powered detailed analysis</p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto max-h-[60vh]">
              <div className="flex items-center gap-6 mb-6 p-4 bg-slate-800/50 rounded-xl">
                <div className="text-center">
                  <div className="text-4xl font-bold text-white">{breakdown.score}</div>
                  <div className="text-xs text-slate-500">Current Score</div>
                </div>
                <div className="flex-1">
                  <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        breakdown.score >= 80 ? 'bg-gradient-to-r from-emerald-500 to-teal-400' :
                        breakdown.score >= 60 ? 'bg-gradient-to-r from-blue-500 to-cyan-400' :
                        breakdown.score >= 40 ? 'bg-gradient-to-r from-amber-500 to-orange-400' :
                        'bg-gradient-to-r from-red-500 to-rose-400'
                      }`}
                      style={{ width: `${breakdown.score}%` }}
                    />
                  </div>
                  <div className="flex justify-between mt-2 text-xs text-slate-500">
                    <span>0</span>
                    <span>Target: 80+</span>
                    <span>100</span>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-semibold text-white mb-3">Quick Summary</h3>
                <p className="text-slate-400">{breakdown.recommendation}</p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-400" />
                  AI Recommendations
                </h3>
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 text-emerald-400 animate-spin" />
                    <span className="ml-3 text-slate-400">Generating personalized advice...</span>
                  </div>
                ) : (
                  <div className="prose prose-invert prose-sm max-w-none">
                    <div className="text-slate-300 whitespace-pre-wrap leading-relaxed">
                      {recommendations}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-900/50">
              <button
                onClick={onClose}
                className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold hover:from-emerald-600 hover:to-teal-600 transition-all"
              >
                Got it!
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
