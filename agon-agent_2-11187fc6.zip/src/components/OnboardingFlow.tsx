import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ChevronLeft, User, Wallet, PiggyBank, Shield, TrendingUp, Target } from 'lucide-react';
import type { UserProfile } from '../types/finance';

interface OnboardingFlowProps {
  onComplete: (profile: UserProfile) => void;
}

const investmentOptions = [
  { id: 'stocks', label: 'Direct Stocks' },
  { id: 'equity-mf', label: 'Equity Mutual Funds' },
  { id: 'debt-mf', label: 'Debt Mutual Funds' },
  { id: 'elss', label: 'ELSS (Tax Saving)' },
  { id: 'ppf', label: 'PPF' },
  { id: 'nps', label: 'NPS' },
  { id: 'fd', label: 'Fixed Deposits' },
  { id: 'gold', label: 'Gold/SGBs' },
  { id: 'real-estate', label: 'Real Estate' },
  { id: 'bonds', label: 'Bonds' },
];

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState<Partial<UserProfile>>({
    name: '',
    age: 30,
    monthlyIncome: 100000,
    monthlyExpenses: 60000,
    existingInvestments: 500000,
    existingDebts: 0,
    emergencyFund: 200000,
    hasHealthInsurance: false,
    hasLifeInsurance: false,
    hasTermInsurance: false,
    investmentTypes: [],
    taxRegime: 'new',
    riskTolerance: 'moderate',
    retirementAge: 60,
    dependents: 0,
  });

  const steps = [
    { icon: User, title: 'Personal Info', subtitle: 'Tell us about yourself' },
    { icon: Wallet, title: 'Income & Expenses', subtitle: 'Your monthly cash flow' },
    { icon: PiggyBank, title: 'Savings & Debt', subtitle: 'Current financial position' },
    { icon: Shield, title: 'Insurance', subtitle: 'Your protection coverage' },
    { icon: TrendingUp, title: 'Investments', subtitle: 'Where you invest' },
    { icon: Target, title: 'Goals & Risk', subtitle: 'Your financial goals' },
  ];

  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const toggleInvestment = (id: string) => {
    const current = profile.investmentTypes || [];
    if (current.includes(id)) {
      updateProfile({ investmentTypes: current.filter(t => t !== id) });
    } else {
      updateProfile({ investmentTypes: [...current, id] });
    }
  };

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      onComplete(profile as UserProfile);
    }
  };

  const handleBack = () => {
    if (step > 0) setStep(step - 1);
  };

  const renderStep = () => {
    switch (step) {
      case 0:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Your Name</label>
              <input
                type="text"
                value={profile.name}
                onChange={(e) => updateProfile({ name: e.target.value })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                placeholder="Enter your name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Your Age</label>
              <input
                type="number"
                value={profile.age}
                onChange={(e) => updateProfile({ age: parseInt(e.target.value) || 0 })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Number of Dependents</label>
              <input
                type="number"
                value={profile.dependents}
                onChange={(e) => updateProfile({ dependents: parseInt(e.target.value) || 0 })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                min="0"
              />
            </div>
          </div>
        );
      
      case 1:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Monthly Income (₹)</label>
              <input
                type="number"
                value={profile.monthlyIncome}
                onChange={(e) => updateProfile({ monthlyIncome: parseInt(e.target.value) || 0 })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <p className="text-xs text-slate-500 mt-1">Include salary, rental income, freelance, etc.</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Monthly Expenses (₹)</label>
              <input
                type="number"
                value={profile.monthlyExpenses}
                onChange={(e) => updateProfile({ monthlyExpenses: parseInt(e.target.value) || 0 })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <p className="text-xs text-slate-500 mt-1">Rent, EMIs, groceries, utilities, lifestyle</p>
            </div>
            <div className="bg-slate-800/30 rounded-xl p-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Monthly Savings</span>
                <span className="text-emerald-400 font-semibold text-lg">
                  ₹{((profile.monthlyIncome || 0) - (profile.monthlyExpenses || 0)).toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-slate-400">Savings Rate</span>
                <span className="text-emerald-400 font-semibold">
                  {(((profile.monthlyIncome || 0) - (profile.monthlyExpenses || 0)) / (profile.monthlyIncome || 1) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        );
      
      case 2:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Total Investments (₹)</label>
              <input
                type="number"
                value={profile.existingInvestments}
                onChange={(e) => updateProfile({ existingInvestments: parseInt(e.target.value) || 0 })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <p className="text-xs text-slate-500 mt-1">MF, stocks, FD, PPF, NPS, gold, etc.</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Emergency Fund (₹)</label>
              <input
                type="number"
                value={profile.emergencyFund}
                onChange={(e) => updateProfile({ emergencyFund: parseInt(e.target.value) || 0 })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <p className="text-xs text-slate-500 mt-1">Liquid cash for emergencies</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Total Outstanding Debt (₹)</label>
              <input
                type="number"
                value={profile.existingDebts}
                onChange={(e) => updateProfile({ existingDebts: parseInt(e.target.value) || 0 })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <p className="text-xs text-slate-500 mt-1">Home loan, car loan, personal loan, credit card</p>
            </div>
          </div>
        );
      
      case 3:
        return (
          <div className="space-y-6">
            <p className="text-slate-400 text-sm">Select all insurance policies you currently have:</p>
            
            <label className="flex items-center gap-4 p-4 bg-slate-800/30 rounded-xl cursor-pointer hover:bg-slate-800/50 transition-colors">
              <input
                type="checkbox"
                checked={profile.hasHealthInsurance}
                onChange={(e) => updateProfile({ hasHealthInsurance: e.target.checked })}
                className="w-5 h-5 rounded border-slate-600 text-emerald-500 focus:ring-emerald-500 bg-slate-700"
              />
              <div>
                <span className="text-white font-medium">Health Insurance</span>
                <p className="text-xs text-slate-500">Mediclaim or corporate health cover</p>
              </div>
            </label>
            
            <label className="flex items-center gap-4 p-4 bg-slate-800/30 rounded-xl cursor-pointer hover:bg-slate-800/50 transition-colors">
              <input
                type="checkbox"
                checked={profile.hasTermInsurance}
                onChange={(e) => updateProfile({ hasTermInsurance: e.target.checked })}
                className="w-5 h-5 rounded border-slate-600 text-emerald-500 focus:ring-emerald-500 bg-slate-700"
              />
              <div>
                <span className="text-white font-medium">Term Life Insurance</span>
                <p className="text-xs text-slate-500">Pure protection plan with high cover</p>
              </div>
            </label>
            
            <label className="flex items-center gap-4 p-4 bg-slate-800/30 rounded-xl cursor-pointer hover:bg-slate-800/50 transition-colors">
              <input
                type="checkbox"
                checked={profile.hasLifeInsurance}
                onChange={(e) => updateProfile({ hasLifeInsurance: e.target.checked })}
                className="w-5 h-5 rounded border-slate-600 text-emerald-500 focus:ring-emerald-500 bg-slate-700"
              />
              <div>
                <span className="text-white font-medium">Traditional Life Insurance</span>
                <p className="text-xs text-slate-500">LIC, endowment, ULIP policies</p>
              </div>
            </label>
          </div>
        );
      
      case 4:
        return (
          <div className="space-y-4">
            <p className="text-slate-400 text-sm">Select all investment types you currently hold:</p>
            <div className="grid grid-cols-2 gap-3">
              {investmentOptions.map((option) => (
                <button
                  key={option.id}
                  onClick={() => toggleInvestment(option.id)}
                  className={`p-3 rounded-xl text-left transition-all ${
                    profile.investmentTypes?.includes(option.id)
                      ? 'bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400'
                      : 'bg-slate-800/30 border-2 border-transparent text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  <span className="text-sm font-medium">{option.label}</span>
                </button>
              ))}
            </div>
          </div>
        );
      
      case 5:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Target Retirement Age</label>
              <input
                type="number"
                value={profile.retirementAge}
                onChange={(e) => updateProfile({ retirementAge: parseInt(e.target.value) || 60 })}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                min={profile.age}
                max="80"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-3">Tax Regime</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => updateProfile({ taxRegime: 'old' })}
                  className={`p-4 rounded-xl transition-all ${
                    profile.taxRegime === 'old'
                      ? 'bg-emerald-500/20 border-2 border-emerald-500'
                      : 'bg-slate-800/30 border-2 border-transparent hover:bg-slate-800/50'
                  }`}
                >
                  <span className="text-white font-medium">Old Regime</span>
                  <p className="text-xs text-slate-500 mt-1">With deductions</p>
                </button>
                <button
                  onClick={() => updateProfile({ taxRegime: 'new' })}
                  className={`p-4 rounded-xl transition-all ${
                    profile.taxRegime === 'new'
                      ? 'bg-emerald-500/20 border-2 border-emerald-500'
                      : 'bg-slate-800/30 border-2 border-transparent hover:bg-slate-800/50'
                  }`}
                >
                  <span className="text-white font-medium">New Regime</span>
                  <p className="text-xs text-slate-500 mt-1">Lower rates</p>
                </button>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-3">Risk Tolerance</label>
              <div className="grid grid-cols-3 gap-3">
                {(['conservative', 'moderate', 'aggressive'] as const).map((risk) => (
                  <button
                    key={risk}
                    onClick={() => updateProfile({ riskTolerance: risk })}
                    className={`p-3 rounded-xl transition-all capitalize ${
                      profile.riskTolerance === risk
                        ? 'bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400'
                        : 'bg-slate-800/30 border-2 border-transparent text-slate-300 hover:bg-slate-800/50'
                    }`}
                  >
                    {risk}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  const StepIcon = steps[step].icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-lg"
      >
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            {steps.map((s, i) => {
              const Icon = s.icon;
              return (
                <div
                  key={i}
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                    i <= step
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
              );
            })}
          </div>
          <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400"
              initial={{ width: 0 }}
              animate={{ width: `${((step + 1) / steps.length) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        {/* Card */}
        <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-2xl p-8">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <StepIcon className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">{steps[step].title}</h2>
              <p className="text-slate-400 text-sm">{steps[step].subtitle}</p>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {renderStep()}
            </motion.div>
          </AnimatePresence>

          <div className="flex gap-4 mt-8">
            {step > 0 && (
              <button
                onClick={handleBack}
                className="flex-1 py-3 px-6 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
              >
                <ChevronLeft className="w-5 h-5" />
                Back
              </button>
            )}
            <button
              onClick={handleNext}
              className="flex-1 py-3 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold hover:from-emerald-600 hover:to-teal-600 transition-all flex items-center justify-center gap-2"
            >
              {step === steps.length - 1 ? 'Get My Score' : 'Continue'}
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <p className="text-center text-slate-500 text-sm mt-6">
          🔒 Your data is processed locally and never stored
        </p>
      </motion.div>
    </div>
  );
}
