import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus, ChevronRight, Sparkles } from 'lucide-react';
import type { ScoreBreakdown } from '../types/finance';

interface ScoreCardProps {
  breakdown: ScoreBreakdown;
  index: number;
  onClick: () => void;
}

export default function ScoreCard({ breakdown, index, onClick }: ScoreCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'text-emerald-400 bg-emerald-500/20';
      case 'good': return 'text-blue-400 bg-blue-500/20';
      case 'needs-attention': return 'text-amber-400 bg-amber-500/20';
      case 'critical': return 'text-red-400 bg-red-500/20';
      default: return 'text-slate-400 bg-slate-500/20';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'excellent': return <TrendingUp className="w-4 h-4" />;
      case 'good': return <TrendingUp className="w-4 h-4" />;
      case 'needs-attention': return <Minus className="w-4 h-4" />;
      case 'critical': return <TrendingDown className="w-4 h-4" />;
      default: return <Minus className="w-4 h-4" />;
    }
  };

  const getProgressColor = (score: number) => {
    if (score >= 80) return 'from-emerald-500 to-teal-400';
    if (score >= 60) return 'from-blue-500 to-cyan-400';
    if (score >= 40) return 'from-amber-500 to-orange-400';
    return 'from-red-500 to-rose-400';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      onClick={onClick}
      className="bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-5 hover:bg-slate-800/50 transition-all cursor-pointer group"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-white font-semibold mb-1">{breakdown.dimension}</h3>
          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${getStatusColor(breakdown.status)}`}>
            {getStatusIcon(breakdown.status)}
            <span className="capitalize">{breakdown.status.replace('-', ' ')}</span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-white">{breakdown.score}</div>
          <div className="text-xs text-slate-500">/ {breakdown.maxScore}</div>
        </div>
      </div>

      <div className="h-2 bg-slate-700/50 rounded-full overflow-hidden mb-4">
        <motion.div
          className={`h-full bg-gradient-to-r ${getProgressColor(breakdown.score)}`}
          initial={{ width: 0 }}
          animate={{ width: `${breakdown.score}%` }}
          transition={{ duration: 0.8, delay: index * 0.1 }}
        />
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400 flex-1">{breakdown.recommendation}</p>
        <div className="flex items-center gap-1 text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity ml-3">
          <Sparkles className="w-4 h-4" />
          <span className="text-xs font-medium">AI Tips</span>
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>
    </motion.div>
  );
}
