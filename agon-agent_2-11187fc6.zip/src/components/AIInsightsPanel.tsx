import { motion } from 'framer-motion';
import { Sparkles, AlertCircle, CheckCircle, Clock, ChevronRight, Loader2 } from 'lucide-react';
import type { AIInsight } from '../types/finance';

interface AIInsightsPanelProps {
  insights: AIInsight[];
  loading: boolean;
}

export default function AIInsightsPanel({ insights, loading }: AIInsightsPanelProps) {
  const getPriorityStyles = (priority: string) => {
    switch (priority) {
      case 'high':
        return { bg: 'bg-red-500/10 border-red-500/30', icon: AlertCircle, iconColor: 'text-red-400' };
      case 'medium':
        return { bg: 'bg-amber-500/10 border-amber-500/30', icon: Clock, iconColor: 'text-amber-400' };
      case 'low':
        return { bg: 'bg-emerald-500/10 border-emerald-500/30', icon: CheckCircle, iconColor: 'text-emerald-400' };
      default:
        return { bg: 'bg-slate-500/10 border-slate-500/30', icon: CheckCircle, iconColor: 'text-slate-400' };
    }
  };

  if (loading) {
    return (
      <div className="bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">AI Financial Insights</h2>
            <p className="text-slate-400 text-sm">Analyzing your profile...</p>
          </div>
        </div>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
          <span className="ml-3 text-slate-400">Generating personalized recommendations...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white">AI Financial Insights</h2>
          <p className="text-slate-400 text-sm">Personalized recommendations for you</p>
        </div>
      </div>

      <div className="space-y-4">
        {insights.map((insight, index) => {
          const { bg, icon: Icon, iconColor } = getPriorityStyles(insight.priority);
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.15 }}
              className={`${bg} border rounded-xl p-5`}
            >
              <div className="flex items-start gap-4">
                <Icon className={`w-5 h-5 ${iconColor} mt-0.5 flex-shrink-0`} />
                <div className="flex-1">
                  <h3 className="text-white font-semibold mb-1">{insight.title}</h3>
                  <p className="text-slate-400 text-sm mb-3">{insight.description}</p>
                  <div className="space-y-2">
                    {insight.actionItems.map((action, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <ChevronRight className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                        <span className="text-slate-300">{action}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-full capitalize ${
                  insight.priority === 'high' ? 'bg-red-500/20 text-red-400' :
                  insight.priority === 'medium' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-emerald-500/20 text-emerald-400'
                }`}>
                  {insight.priority}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
